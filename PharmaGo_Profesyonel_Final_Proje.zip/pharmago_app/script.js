const demoUser={name:'Salih Efe Akardere',studentNo:'24010501061',tc:'12345678901'};
const products=[
{id:1,name:'Parol 500 mg',cat:'Reçetesiz',price:89,icon:'💊',desc:'Ağrı kesici / ateş düşürücü'},
{id:2,name:'C Vitamini 1000 mg',cat:'Vitamin',price:145,icon:'🍊',desc:'Bağışıklık desteği'},
{id:3,name:'Tansiyon İlacı',cat:'Reçeteli',price:210,icon:'🫀',desc:'e-Nabız reçetesi gerekir'},
{id:4,name:'Ateş Ölçer',cat:'Medikal',price:320,icon:'🌡️',desc:'Dijital ölçüm cihazı'},
{id:5,name:'Boğaz Pastili',cat:'Reçetesiz',price:75,icon:'🍬',desc:'Boğaz rahatlatıcı'},
{id:6,name:'Şeker Ölçüm Strip',cat:'Medikal',price:260,icon:'🩸',desc:'Diyabet takip ürünü'},
{id:7,name:'D Vitamini',cat:'Vitamin',price:170,icon:'☀️',desc:'Günlük vitamin desteği'},
{id:8,name:'Antibiyotik Reçetesi',cat:'Reçeteli',price:185,icon:'🧾',desc:'Sadece reçete ile sipariş'}
];
const recipes=[
{title:'Reçete #RX-2026-001',doctor:'Dr. Ayşe Demir',items:['Tansiyon İlacı','D Vitamini']},
{title:'Reçete #RX-2026-002',doctor:'Dr. Mehmet Kaya',items:['Antibiyotik Reçetesi','Boğaz Pastili']}
];
let cart=JSON.parse(localStorage.getItem('pg_cart')||'[]');
let orders=JSON.parse(localStorage.getItem('pg_orders')||'[]');
let connected=localStorage.getItem('pg_enabiz')==='1';
let trackIndex=0;
const statuses=['Sipariş Alındı','Eczane Onayladı','Kurye Yola Çıktı','Adrese Yaklaştı','Teslim Edildi'];
const $=id=>document.getElementById(id);
function save(){localStorage.setItem('pg_cart',JSON.stringify(cart));localStorage.setItem('pg_orders',JSON.stringify(orders));}
function toast(msg){const t=$('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2200)}
function show(screen){document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));$(screen).classList.add('active');document.querySelectorAll('.nav').forEach(n=>n.classList.toggle('active',n.dataset.screen===screen));const names={dashboard:'Ana Sayfa',profile:'Demo Kullanıcı',enabiz:'e-Nabız',products:'Ürünler',cart:'Sepet & Ödeme',tracking:'Sipariş Takibi',history:'Sipariş Geçmişi',support:'Destek',admin:'Admin Panel'};$('pageTitle').textContent=names[screen];}
document.querySelectorAll('.nav,.go').forEach(b=>b.onclick=()=>show(b.dataset.screen));
$('darkModeBtn').onclick=()=>{document.body.classList.toggle('dark');toast('Tema değiştirildi')};
$('resetBtn').onclick=()=>{if(confirm('Demo verileri sıfırlansın mı?')){cart=[];orders=[];connected=false;trackIndex=0;localStorage.clear();renderAll();toast('Demo sıfırlandı')}};
function renderProducts(){const q=$('searchProduct').value.toLowerCase();const cat=$('categoryFilter').value;let list=products.filter(p=>(cat==='all'||p.cat===cat)&&(p.name.toLowerCase().includes(q)||p.desc.toLowerCase().includes(q)));$('productList').innerHTML=list.map(p=>`<div class="card product"><div class="icon">${p.icon}</div><span class="pill">${p.cat}</span><h3>${p.name}</h3><p>${p.desc}</p><div class="price">${p.price} TL</div><button class="primary" onclick="addCart(${p.id})">Sepete Ekle</button></div>`).join('')||'<div class="card">Ürün bulunamadı.</div>';}
$('searchProduct').oninput=renderProducts;$('categoryFilter').onchange=renderProducts;
window.addCart=id=>{cart.push(products.find(p=>p.id===id));save();renderAll();toast('Ürün sepete eklendi')};
window.removeCart=i=>{cart.splice(i,1);save();renderAll();toast('Ürün sepetten çıkarıldı')};
function renderCart(){$('cartItems').innerHTML=cart.map((p,i)=>`<div class="cart-row"><span>${p.icon} ${p.name}</span><b>${p.price} TL</b><button onclick="removeCart(${i})">Sil</button></div>`).join('')||'<p>Sepetiniz boş.</p>';const total=cart.reduce((a,b)=>a+b.price,0);$('cartTotal').textContent=total+' TL';$('cartCountDash').textContent=cart.length+' ürün';}
$('connectEnabiz').onclick=()=>{if($('tcInput').value!==demoUser.tc){toast('Demo TC: 12345678901 olmalı');return}connected=true;localStorage.setItem('pg_enabiz','1');renderRecipes();renderAll();toast('e-Nabız bağlantısı başarılı')};
function renderRecipes(){if(!connected){$('recipes').classList.add('hidden');return}$('recipes').classList.remove('hidden');$('recipes').innerHTML=recipes.map((r,idx)=>`<div class="card"><h3>${r.title}</h3><p>${r.doctor}</p><ul>${r.items.map(i=>`<li>${i}</li>`).join('')}</ul><button class="secondary" onclick="addRecipe(${idx})">Reçetedeki Ürünleri Sepete Ekle</button></div>`).join('');}
window.addRecipe=idx=>{recipes[idx].items.forEach(name=>{const p=products.find(x=>x.name===name);if(p)cart.push(p)});save();renderAll();toast('Reçete ürünleri sepete eklendi')};
$('createOrder').onclick=()=>{if(cart.length===0){toast('Sipariş için sepete ürün ekleyin');return}const total=cart.reduce((a,b)=>a+b.price,0);const code='PG-'+Math.floor(100000+Math.random()*900000);orders.unshift({code,total,payment:$('payment').value,status:'Sipariş Alındı',items:[...cart]});cart=[];trackIndex=0;save();renderAll();show('tracking');toast('Sipariş oluşturuldu: '+code)};
$('nextTrack').onclick=()=>{if(!orders.length){toast('Aktif sipariş yok');return}if(trackIndex<statuses.length-1)trackIndex++;orders[0].status=statuses[trackIndex];save();renderAll();toast('Durum güncellendi')};
function renderTracking(){if(!orders.length){$('orderCode').textContent='Aktif sipariş bulunmuyor.'}else{$('orderCode').innerHTML=`Sipariş No: <b>${orders[0].code}</b> | Durum: <b>${orders[0].status}</b>`}$('trackLine').innerHTML=statuses.map((s,i)=>`<div class="track-step ${i<=trackIndex&&orders.length?'done':''}">${s}</div>`).join('');$('lastOrderDash').textContent=orders[0]?.status||'Sipariş yok';}
function renderHistory(){$('historyBody').innerHTML=orders.map(o=>`<tr><td>${o.code}</td><td>${o.total} TL</td><td>${o.payment}</td><td>${o.status}</td></tr>`).join('')||'<tr><td colspan="4">Henüz sipariş yok.</td></tr>';$('adminOrders').textContent=orders.length;$('adminRevenue').textContent=orders.reduce((a,b)=>a+b.total,0)+' TL';}
$('sendSupport').onclick=()=>{const msg=$('supportMsg').value.trim();if(!msg){toast('Mesaj alanı boş bırakılamaz');return}$('supportResult').textContent='Sayın Salih Efe Akardere, destek mesajınız alındı. En kısa sürede dönüş yapılacaktır.';$('supportMsg').value='';toast('Destek mesajı gönderildi')};
function renderAll(){renderProducts();renderCart();renderRecipes();renderTracking();renderHistory();$('recipeStatus').textContent=connected?'e-Nabız bağlı':'Reçete bekliyor'}
renderAll();
